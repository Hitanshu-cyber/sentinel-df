# 🛡️ SENTINEL-DF

**Autonomous Edge-Based Deepfake Detection System for Field Operations**

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://python.org)
[![Flutter](https://img.shields.io/badge/Flutter-3.0+-02569B.svg)](https://flutter.dev)
[![TensorFlow](https://img.shields.io/badge/TensorFlow-2.19-FF6F00.svg)](https://tensorflow.org)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

## 🎯 Problem Statement

In military and law enforcement operations, **authenticating digital media in real-time** is critical for:
- Verifying identities during field missions
- Detecting AI-generated propaganda
- Ensuring chain of custody for evidence
- Operating in **offline, low-power environments**

**Sentinel-DF** solves this with a **lightweight, edge-optimized deepfake detection agent** that runs entirely on-device.

---

## ✨ Key Features

### 🚀 **Edge-First Architecture**
- **14MB model** - Runs on smartphones, body-cams, tablets
- **Offline operation** - Zero cloud dependency
- **Low-power** - Optimized with MobileNetV2 quantization
- **50ms inference** - Real-time detection

### 🔒 **Production-Hardened**
- **Chain of Custody** - SHA-256 cryptographic logging
- **Fail-Secure** - No false positives when sensors fail
- **Adversarial Resilience** - Tested against 3 attack vectors
- **Multi-Modal** - Supports video, images, and live camera

### 🎖️ **Field-Ready**
- **Python Backend** - CLI tool for analysts
- **Flutter Mobile App** - Tactical interface for operatives
- **Immediate Results** - Green/Red verdict in <100ms
- **Cognitive Assistance** - Low-light warnings, quality checks

---

## 📦 Repository Structure

```
ANTIP1/
├── ml_core/                    # Python Backend
│   ├── dist/
│   │   └── sentinel_core.tflite   # 14MB trained model
│   ├── verify_inference.py        # CLI detection tool
│   ├── train_detect.py           # Model training pipeline
│   └── tools/
│       ├── simulate_attacks.py    # Adversarial testing
│       └── test_random_batch.py   # Accuracy validation
│
├── sentinel_df/                # Flutter Mobile App
│   ├── lib/
│   │   └── services/
│   │       └── detection_service.dart  # TFLite integration
│   ├── assets/
│   │   └── sentinel_core.tflite        # On-device model
│   └── pubspec.yaml
│
├── README.md                   # This file
└── DEPLOYMENT.md              # Setup & deployment guide
```

---

## 🚀 Quick Start

### Python Backend

```bash
cd ml_core
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Analyze video
python verify_inference.py path/to/video.mp4
```

### Mobile App

```bash
cd sentinel_df
flutter pub get
flutter run  # Connect Android/iOS device
```

---

## 🧪 Validation & Testing

### Adversarial Attack Simulation

Proves resilience against real-world threats:

```bash
cd ml_core/tools
python simulate_attacks.py
```

**Results:**
- ✅ **Deepfake Injection** - 71.7% detection accuracy
- ✅ **Low Light Sabotage** - Warning triggered at <30/255 brightness
- ✅ **Physical Occlusion** - Fail-secure (no false positives)

### Random Batch Testing

Unbiased accuracy validation on 20 random videos:

```bash
python test_random_batch.py
```

---

## 📊 Technical Specifications

| Metric | Value |
|:---|:---|
| **Model Architecture** | MobileNetV2 (Quantized) |
| **Input Size** | 224x224x3 RGB |
| **Model Size** | 14.2 MB |
| **Inference Time** | ~50ms (CPU) |
| **Accuracy** | 71.7%+ on deepfakes |
| **Power Consumption** | Low (edge-optimized) |
| **Offline Support** | ✅ 100% |

---

## 🎥 Demo

**Python CLI:**
```bash
$ python verify_inference.py deepfake_video.mp4
Loading Production Model: dist/sentinel_core.tflite
Analyzing deepfake_video.mp4...
Result: DEEPFAKE (87.3% confidence)
Analysis complete in 2.4s
```

**Mobile App:**
- Live camera feed with real-time face detection
- Instant AUTHENTIC/DEEPFAKE verdict
- Chain of custody export for evidence

---

## 🛠️ Technology Stack

- **ML Framework:** TensorFlow 2.19, TFLite
- **Architecture:** MobileNetV2 (Transfer Learning)
- **Backend:** Python 3.8+
- **Mobile:** Flutter 3.0+ (Dart)
- **Dependencies:** OpenCV, NumPy, SciPy

---

## 📄 Documentation

- **[Deployment Guide](DEPLOYMENT.md)** - Complete setup instructions
- **[Project Audit](docs/project_audit.md)** - Architecture & compliance
- **[Walkthrough](docs/walkthrough.md)** - Feature validation

---

## 🏆 Hackathon Compliance

**Problem Statement:** Create lightweight edge agents for authentication

✅ **On-Device Detection** - Runs on smartphones/body-cams  
✅ **Offline Operation** - Zero cloud dependency  
✅ **Immediate Results** - <100ms authentication  
✅ **Edge Inference** - TFLite optimized  
✅ **Compression-Aware** - Handles low-quality inputs  
✅ **Cognitive Assistance** - Alerts for low light, occlusion  
✅ **Security** - Chain of custody, fail-secure design  

---

## 📞 Contact

For questions about this project, please open an issue or contact the development team.

---

## 📜 License

MIT License - See [LICENSE](LICENSE) for details

---

**Built for tactical operations. Optimized for the edge. Secured by design.** 🛡️
# sentinel-df
