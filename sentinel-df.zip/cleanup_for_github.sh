#!/bin/bash
# Cleanup script for GitHub preparation
# Removes large datasets and temporary files while preserving code and models

echo "🧹 Cleaning up repository for GitHub..."

# Remove large dataset (24GB+)
echo "Removing dataset/ directory (videos)..."
rm -rf ml_core/dataset/

# Remove processed faces (21k+ images)
echo "Removing dataset_faces/ directory..."
rm -rf ml_core/dataset_faces/

# Remove Python virtual environment
echo "Removing Python venv..."
rm -rf ml_core/venv/

# Remove web app (TF.js broken)
echo "Removing sentient_web/ (TF.js incompatibility)..."
rm -rf sentient_web/

# Remove calibration test files
echo "Removing calibration test data..."
rm -rf ml_core/calibration_dataset/
rm -rf ml_core/test_media/

# Remove temporary SavedModel artifacts
echo "Removing temporary conversion artifacts..."
rm -rf ml_core/dist/saved_model/

# Remove __pycache__ and .pyc files
echo "Removing Python cache files..."
find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null
find . -type f -name "*.pyc" -delete

# Remove any .DS_Store (macOS)
find . -name ".DS_Store" -delete

# Remove Flutter build artifacts
echo "Cleaning Flutter build artifacts..."
cd sentinel_df
flutter clean 2>/dev/null
cd ..

echo "✅ Cleanup complete!"
echo ""
echo "📦 Repository size reduced significantly"
echo "Kept:"
echo "  ✓ Source code (Python + Flutter)"
echo "  ✓ Trained model (sentinel_core.tflite - 14MB)"
echo "  ✓ Documentation"
echo "  ✓ Deployment guides"
