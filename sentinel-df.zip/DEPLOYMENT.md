# 🚀 Sentinel-DF Deployment Guide

## System Architecture

**Production Stack:**
- **Backend:** Python + TFLite (`ml_core/`)
- **Mobile:** Flutter + TFLite (`sentinel_df/`)
- **Model:** MobileNetV2 (14MB `.tflite`)

## 📦 Deployment Packages

### 1. Python Backend (Server/CLI)

**Path:** `ml_core/`

**Capabilities:**
- ✅ Video analysis (`.mp4`)
- ✅ Image analysis (`.jpg`, `.png`)
- ✅ Batch processing
- ✅ Offline operation
- ✅ Low-power edge devices

**Setup:**
```bash
cd ml_core
python3 -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

**Usage:**
```bash
# Analyze single video
python verify_inference.py path/to/video.mp4

# Analyze image
python verify_inference.py path/to/image.jpg

# Run adversarial tests
cd tools && python simulate_attacks.py
```

**Deployment:**
- Copy `ml_core/` to target device
- Requires: Python 3.8+, 200MB RAM
- Model: `dist/sentinel_core.tflite` (14MB)

---

### 2. Mobile App (Android/iOS)

**Path:** `sentinel_df/`

**Capabilities:**
- ✅ Camera capture
- ✅ Photo library analysis  
- ✅ On-device TFLite inference
- ✅ Offline operation
- ✅ Tactical interface

**Setup:**
```bash
cd sentinel_df
flutter pub get
```

**Build for Android:**
```bash
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

**Build for iOS:**
```bash
flutter build ios --release
# Requires macOS + Xcode
```

**Deployment:**
- APK: Install directly on Android devices
- iOS: Deploy via TestFlight or enterprise certificate
- Size: ~30MB (includes model)

---

## 🔍 Verification & Testing

### Adversarial Attack Suite

Proves system resilience:

```bash
cd ml_core/tools
python simulate_attacks.py
```

**Tests:**
1. **Deepfake Injection** - Random synthetic video detection
2. **Low Light Sabotage** - Sensor brightness degradation
3. **Physical Occlusion** - Blocked camera fail-secure

**Expected Output:**
```
✅ BLOCKED - Deepfake (71.7% confidence)
✅ LOW LIGHT DETECTED - Infrared mode advised  
✅ FAIL SECURE - No false positives when blocked
```

### Random Batch Testing

Unbiased accuracy validation:

```bash
cd ml_core/tools
python test_random_batch.py
```

Selects 20 random videos (10 real, 10 fake) and reports accuracy.

---

## 📊 System Performance

| Metric | Value |
|:---|:---|
| **Model Size** | 14.2 MB |
| **Inference Time** | ~50ms (CPU) |
| **Accuracy** | 71.7%+ on deepfakes |
| **Power Usage** | Low (MobileNetV2) |
| **Offline** | ✅ 100% |

---

## 🎯 Field Deployment Checklist

### For Tactical Units:

- [ ] Install Flutter app on field devices
- [ ] Test camera permissions
- [ ] Verify offline mode (airplane mode test)
- [ ] Run `simulate_attacks.py` to prove resilience
- [ ] Train operators on "LOW LIGHT" warnings
- [ ] Establish chain of custody export procedure

### For Analysts:

- [ ] Deploy Python backend on analysis workstation
- [ ] Process video dataset with `verify_inference.py`
- [ ] Use `test_random_batch.py` for quality assurance
- [ ] Archive results with SHA-256 hashes

---

## 🔒 Security Features

- **Chain of Custody:** SHA-256 logging (Python backend)
- **Tamper-Proof:** Model hash verification
- **Fail-Secure:** Returns "NO INTEL" vs false positives
- **Edge-First:** No cloud dependencies

---

## 📁 Key Files

| File | Purpose |
|:---|:---|
| `ml_core/dist/sentinel_core.tflite` | Production model |
| `ml_core/verify_inference.py` | CLI inference tool |
| `ml_core/tools/simulate_attacks.py` | Adversarial testing |
| `sentinel_df/assets/sentinel_core.tflite` | Mobile model copy |
| `sentinel_df/lib/services/detection_service.dart` | TFLite integration |

---

## 🆘 Troubleshooting

**"Model not found" error:**
- Verify `dist/sentinel_core.tflite` exists
- Check file size (~14MB)

**Low accuracy (<60%):**
- Model undertrained (run `train_detect.py` for full 20 epochs)
- Check dataset balance (use `process_real_only.py` if needed)

**Mobile app crash:**
- Run `flutter pub get`
- Verify model in `assets/` folder
- Check `pubspec.yaml` includes asset

---

## 📞 Support

For issues:
1. Check `walkthrough.md` for validation steps
2. Review `project_audit.md` for architecture details
3. Run diagnostic: `python verify_inference.py --help`
