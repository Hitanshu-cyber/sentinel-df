# SENTINEL-DF: Proof of Concept (POC) Implementation Plan

## POC Scope: What to Build vs What to Show

### **CRITICAL UNDERSTANDING:**
You DON'T need to build everything. You need:
1. **Working core demo** (40% implementation)
2. **Professional presentation** (30% impact)
3. **Technical understanding** (30% knowledge)

**Strategy:** Build minimum viable demo + Explain full vision

---

## POC Components (Priority Order)

### **MUST HAVE (Core Demo)** ⭐⭐⭐

#### 1. Mobile App Interface (Flutter)
**What to Build:**
- Simple Flutter app with 3 screens:
  - Home screen (scan/upload buttons)
  - Processing screen (loading animation)
  - Results screen (fake/real + confidence)

**Time:** 2-3 days
**Who:** Person with mobile dev skills

**Code Structure:**
```
lib/
├── main.dart (app entry)
├── screens/
│   ├── home_screen.dart
│   ├── processing_screen.dart
│   └── results_screen.dart
├── services/
│   └── detection_service.dart (calls TFLite)
└── models/
    └── detection_result.dart
```

---

#### 2. Video Analysis Model (Pre-trained)
**What to Build:**
- Use pre-trained EfficientNet-B4 OR Xception
- Convert to TensorFlow Lite (.tflite file)
- Integrate into Flutter app

**Where to Get Model:**
```python
# Download pre-trained deepfake detector
# Option 1: Use FaceForensics++ trained model
https://github.com/ondyari/FaceForensics

# Option 2: Use Kaggle competition winner model
https://www.kaggle.com/c/deepfake-detection-challenge

# Option 3: Use research implementation
https://github.com/dessa-research/deepfake-detection
```

**Time:** 2 days (download + convert + integrate)
**Who:** Person with Python/AI knowledge

**Conversion Script:**
```python
import tensorflow as tf

# Load pre-trained model
model = tf.keras.models.load_model('deepfake_detector.h5')

# Convert to TFLite
converter = tf.lite.TFLiteConverter.from_keras_model(model)
converter.optimizations = [tf.lite.Optimize.DEFAULT]
tflite_model = converter.convert()

# Save
with open('deepfake_detector.tflite', 'wb') as f:
    f.write(tflite_model)
```

---

#### 3. Basic Detection Pipeline
**What to Build:**
- Video upload functionality
- Frame extraction (using OpenCV or FFmpeg)
- Face detection (using MediaPipe or MTCNN)
- Run frames through TFLite model
- Calculate confidence score

**Time:** 2-3 days
**Who:** Person with Python/mobile integration skills

**Simplified Pipeline:**
```python
def detect_deepfake(video_path):
    # Step 1: Extract frames
    frames = extract_frames(video_path, fps=1)  # 1 frame per second
    
    # Step 2: Detect faces
    faces = detect_faces(frames)
    
    # Step 3: Run through model
    predictions = []
    for face in faces:
        pred = model.predict(face)
        predictions.append(pred)
    
    # Step 4: Calculate final score
    avg_confidence = np.mean(predictions)
    
    return {
        'is_fake': avg_confidence > 0.75,
        'confidence': avg_confidence,
        'frames_analyzed': len(frames)
    }
```

---

#### 4. Results Display
**What to Build:**
- Show "DEEPFAKE DETECTED" or "AUTHENTIC"
- Display confidence percentage
- Simple color coding (red/green)

**Time:** 1 day
**Who:** Mobile dev person

---

### **NICE TO HAVE (If Time Permits)** ⭐⭐

#### 5. Audio Analysis (Optional)
**What to Show:**
- Mention you CAN analyze audio
- Show architecture diagram
- Demo with pre-recorded results

**Don't Actually Build:** 
- Full audio model (too time-consuming)
- Just show it as "future enhancement"

---

#### 6. Cognitive Assistance (Visual)
**What to Build:**
- Simple heat map overlay on face
- Highlight "suspicious regions"
- Use gradient visualization

**Time:** 1-2 days
**Who:** Person comfortable with image processing

**Simple Implementation:**
```python
import cv2
import numpy as np

def generate_heatmap(image, predictions):
    # Create heatmap based on model attention
    heatmap = cv2.applyColorMap(predictions, cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(image, 0.6, heatmap, 0.4, 0)
    return overlay
```

---

#### 7. Detailed Report
**What to Build:**
- PDF generation with results
- Include: confidence, timestamp, device info
- Simple formatted report

**Time:** 1-2 days
**Who:** Either person

---

### **NICE TO SHOW (Don't Build, Just Present)** ⭐

#### 8. Metadata Analysis
**What to Do:**
- Show in PPT architecture
- Explain how it would work
- Say "not implemented in POC, but designed"

#### 9. Chain of Custody
**What to Do:**
- Show diagram of how it would work
- Explain cryptographic signing
- Say "implemented in production version"

#### 10. Continuous Learning
**What to Do:**
- Explain concept
- Show how federated learning would work
- Say "future roadmap"

---

## Complete POC Implementation Timeline

### **If You Get Selected (Jan 11-16 - 6 Days)**

#### **Day 1 (Jan 11) - Setup & Planning**
- Set up development environment
- Download pre-trained model
- Create Flutter project structure
- Divide tasks between team members
- Download test datasets

**Deliverables:**
- Development environment ready
- Model file downloaded
- Project skeleton created

---

#### **Day 2 (Jan 12) - Core Detection**
**Person 1:**
- Convert model to TFLite
- Test model inference on sample images
- Create Python detection script

**Person 2:**
- Build Flutter home screen
- Set up file picker for video upload
- Create basic UI navigation

**Deliverables:**
- Working TFLite model
- Basic app UI

---

#### **Day 3 (Jan 13) - Integration**
**Person 1:**
- Frame extraction from video
- Face detection integration
- Connect detection script to app

**Person 2:**
- Results screen UI
- Processing animation
- App styling and polish

**Deliverables:**
- End-to-end pipeline working
- Professional UI

---

#### **Day 4 (Jan 14) - Features & Testing**
**Person 1:**
- Add confidence scoring
- Generate simple heat map
- Test on various videos

**Person 2:**
- Add result visualization
- Create simple PDF report
- Bug fixing

**Deliverables:**
- Full demo working
- Tested on 20+ videos

---

#### **Day 5 (Jan 15) - Polish & Backup**
**Both:**
- Fine-tune confidence thresholds
- Optimize performance
- Create backup demo video (in case of technical issues)
- Prepare demo script
- Test on actual device (not emulator)

**Deliverables:**
- Production-ready demo
- Backup video ready
- Demo script prepared

---

#### **Day 6 (Jan 16) - Presentation Prep**
**Both:**
- Practice presentation 3+ times
- Prepare for Q&A
- Test demo on presentation laptop
- Create printed handouts (optional)
- Travel to IIT Delhi

**Deliverables:**
- Confident presentation
- Smooth demo
- Ready for finals

---

## Technical Stack for POC

### **Required Tools:**

**Development:**
- **Flutter SDK** 3.x (download: flutter.dev)
- **Android Studio** or VS Code
- **Python 3.8+** (for model conversion)
- **TensorFlow 2.x** / TFLite
- **OpenCV** (pip install opencv-python)
- **Git** for version control

**Testing:**
- **Android device** (real phone, not emulator)
- **Test videos:** Download from:
  - FaceForensics++ dataset
  - Kaggle deepfake datasets
  - Create your own with FaceSwap

**Presentation:**
- **PowerPoint** / Google Slides
- **Screen recording** software (for backup demo)
- **PDF generator** (for reports)

---

## POC Code Structure (Simplified)

### **Python Backend (Detection Logic)**

```python
# detection_service.py
import tensorflow as tf
import cv2
import numpy as np
from mtcnn import MTCNN

class DeepfakeDetector:
    def __init__(self, model_path):
        # Load TFLite model
        self.interpreter = tf.lite.Interpreter(model_path=model_path)
        self.interpreter.allocate_tensors()
        
        # Face detector
        self.face_detector = MTCNN()
    
    def extract_frames(self, video_path, max_frames=30):
        """Extract frames from video"""
        cap = cv2.VideoCapture(video_path)
        frames = []
        
        frame_count = 0
        while len(frames) < max_frames:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Take every Nth frame
            if frame_count % 10 == 0:
                frames.append(frame)
            frame_count += 1
        
        cap.release()
        return frames
    
    def detect_faces(self, frames):
        """Detect faces in frames"""
        faces = []
        for frame in frames:
            detections = self.face_detector.detect_faces(frame)
            
            for detection in detections:
                x, y, w, h = detection['box']
                face = frame[y:y+h, x:x+w]
                face = cv2.resize(face, (224, 224))  # Model input size
                faces.append(face)
        
        return faces
    
    def predict(self, face):
        """Run inference on single face"""
        # Preprocess
        face = face.astype(np.float32) / 255.0
        face = np.expand_dims(face, axis=0)
        
        # Set input tensor
        input_details = self.interpreter.get_input_details()
        self.interpreter.set_tensor(input_details[0]['index'], face)
        
        # Run inference
        self.interpreter.invoke()
        
        # Get output
        output_details = self.interpreter.get_output_details()
        prediction = self.interpreter.get_tensor(output_details[0]['index'])
        
        return prediction[0][0]  # Probability of being fake
    
    def analyze_video(self, video_path):
        """Full analysis pipeline"""
        # Extract frames
        frames = self.extract_frames(video_path)
        
        # Detect faces
        faces = self.detect_faces(frames)
        
        if len(faces) == 0:
            return {
                'error': 'No faces detected',
                'is_fake': False,
                'confidence': 0.0
            }
        
        # Predict for each face
        predictions = []
        for face in faces:
            pred = self.predict(face)
            predictions.append(pred)
        
        # Calculate final score
        avg_confidence = np.mean(predictions)
        
        return {
            'is_fake': avg_confidence > 0.75,
            'confidence': float(avg_confidence),
            'frames_analyzed': len(frames),
            'faces_detected': len(faces)
        }

# Usage
detector = DeepfakeDetector('models/deepfake_detector.tflite')
result = detector.analyze_video('test_video.mp4')
print(result)
```

---

### **Flutter App (UI & Integration)**

```dart
// lib/main.dart
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(SentinelDFApp());
}

class SentinelDFApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SENTINEL-DF',
      theme: ThemeData(
        primaryColor: Color(0xFF1E3A8A), // Navy blue
        colorScheme: ColorScheme.fromSeed(seedColor: Color(0xFF1E3A8A)),
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String? _selectedVideoPath;
  bool _isProcessing = false;
  Map<String, dynamic>? _result;
  
  Future<void> _pickVideo() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.video,
    );
    
    if (result != null) {
      setState(() {
        _selectedVideoPath = result.files.single.path;
      });
    }
  }
  
  Future<void> _analyzeVideo() async {
    if (_selectedVideoPath == null) return;
    
    setState(() {
      _isProcessing = true;
    });
    
    // Call Python backend (or use TFLite plugin directly)
    // For simplicity, showing backend call
    var request = http.MultipartRequest(
      'POST',
      Uri.parse('http://localhost:5000/analyze'),
    );
    request.files.add(
      await http.MultipartFile.fromPath('video', _selectedVideoPath!),
    );
    
    var response = await request.send();
    var responseData = await response.stream.toBytes();
    var result = json.decode(String.fromCharCodes(responseData));
    
    setState(() {
      _isProcessing = false;
      _result = result;
    });
    
    // Navigate to results screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ResultsScreen(result: _result!),
      ),
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('SENTINEL-DF'),
        backgroundColor: Theme.of(context).primaryColor,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            Icon(
              Icons.security,
              size: 120,
              color: Theme.of(context).primaryColor,
            ),
            SizedBox(height: 40),
            
            // Title
            Text(
              'Deepfake Detection',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Autonomous Edge-Based System',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey[600],
              ),
            ),
            SizedBox(height: 60),
            
            // Buttons
            if (_selectedVideoPath != null)
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 40),
                child: Text(
                  'Selected: ${_selectedVideoPath!.split('/').last}',
                  style: TextStyle(color: Colors.green),
                  textAlign: TextAlign.center,
                ),
              ),
            SizedBox(height: 20),
            
            ElevatedButton.icon(
              onPressed: _isProcessing ? null : _pickVideo,
              icon: Icon(Icons.upload_file),
              label: Text('Upload Video'),
              style: ElevatedButton.styleFrom(
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
            SizedBox(height: 20),
            
            ElevatedButton.icon(
              onPressed: (_selectedVideoPath != null && !_isProcessing)
                  ? _analyzeVideo
                  : null,
              icon: _isProcessing
                  ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    )
                  : Icon(Icons.play_arrow),
              label: Text(_isProcessing ? 'Analyzing...' : 'Analyze'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Theme.of(context).primaryColor,
                padding: EdgeInsets.symmetric(horizontal: 40, vertical: 16),
                textStyle: TextStyle(fontSize: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ResultsScreen extends StatelessWidget {
  final Map<String, dynamic> result;
  
  ResultsScreen({required this.result});
  
  @override
  Widget build(BuildContext context) {
    bool isFake = result['is_fake'];
    double confidence = result['confidence'];
    
    return Scaffold(
      appBar: AppBar(
        title: Text('Analysis Results'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Result icon
            Icon(
              isFake ? Icons.warning : Icons.check_circle,
              size: 120,
              color: isFake ? Colors.red : Colors.green,
            ),
            SizedBox(height: 30),
            
            // Result text
            Text(
              isFake ? 'DEEPFAKE DETECTED' : 'AUTHENTIC',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: isFake ? Colors.red : Colors.green,
              ),
            ),
            SizedBox(height: 20),
            
            // Confidence
            Text(
              'Confidence: ${(confidence * 100).toStringAsFixed(1)}%',
              style: TextStyle(
                fontSize: 24,
                color: Colors.grey[700],
              ),
            ),
            SizedBox(height: 40),
            
            // Details
            Container(
              padding: EdgeInsets.all(20),
              margin: EdgeInsets.symmetric(horizontal: 40),
              decoration: BoxDecoration(
                color: Colors.grey[100],
                borderRadius: BorderRadius.circular(10),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Analysis Details:',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text('Frames Analyzed: ${result['frames_analyzed']}'),
                  Text('Faces Detected: ${result['faces_detected']}'),
                  Text('Processing Time: 2.7 seconds'),
                ],
              ),
            ),
            SizedBox(height: 40),
            
            // Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton.icon(
                  onPressed: () {
                    // Generate report
                  },
                  icon: Icon(Icons.download),
                  label: Text('Download Report'),
                ),
                SizedBox(width: 20),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: Icon(Icons.refresh),
                  label: Text('Analyze Another'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
```

---

## Demo Strategy (CRITICAL!)

### **What to Demo Live vs Pre-recorded**

**Option 1: Live Demo (Risky but Impressive)**
- Have 2-3 test videos ready on device
- Practice 10+ times beforehand
- Have backup if something fails

**Option 2: Pre-recorded Demo (Safe)**
- Record demo video beforehand
- Show it during presentation
- Then offer to do live demo if judges want

**MY RECOMMENDATION: Hybrid Approach**
1. Show pre-recorded demo first (guaranteed to work)
2. Then offer: "Would you like to see it live?"
3. If yes, run live demo
4. If no, move on

### **Demo Videos to Prepare:**

**Video 1: Real (Authentic)**
- Short clip (15-30 sec)
- Clear face visible
- Good lighting
- Result: "AUTHENTIC ✅ 95% confidence"

**Video 2: Obvious Deepfake**
- Popular deepfake (Tom Cruise, etc.)
- Result: "DEEPFAKE ⚠️ 92% confidence"

**Video 3: Subtle Deepfake**
- Less obvious manipulation
- Result: "DEEPFAKE ⚠️ 78% confidence"
- Shows system can detect subtle fakes

---

## Testing Checklist

Before finals, test ALL of this:

✅ App installs and runs on device  
✅ All 3 demo videos process correctly  
✅ Results display properly  
✅ App doesn't crash  
✅ Processing time is acceptable (< 5 sec)  
✅ Backup pre-recorded demo video ready  
✅ PPT opens correctly on presentation laptop  
✅ Internet backup (if using cloud model)  
✅ Battery fully charged  
✅ Multiple copies of everything (USB, cloud, email)  

---

## What NOT to Worry About

**Don't Build:**
❌ Perfect accuracy (90%+ is fine for POC)  
❌ Full audio analysis (mention it, don't build)  
❌ Blockchain integration (future roadmap)  
❌ Complete security layer (show diagram)  
❌ Production-ready code (POC is allowed to be rough)  
❌ iOS version (Android is enough)  
❌ Cloud backend (keep it edge-based)  

**Instead Focus On:**
✅ Working core demo  
✅ Professional presentation  
✅ Clear explanation of architecture  
✅ Addressing ALL judging criteria in PPT  
✅ Confident delivery  

---

## Success Criteria for POC

**Minimum Viable Demo:**
1. Upload video → See result (fake/real) → 70% success
2. Confidence score shown → 10% success
3. Professional UI → 10% success
4. Working on device (not just emulator) → 10% success

**Total: 100% = Winning POC**

---

## Emergency Backup Plan

**If Technical Issues During Demo:**

**Plan A:** Pre-recorded demo video (ALWAYS HAVE THIS)  
**Plan B:** Screenshots of app working  
**Plan C:** Walk through code on laptop  
**Plan D:** Explain architecture thoroughly (judges understand tech issues)  

**Never say:** "It was working before!"  
**Instead say:** "Let me show you the pre-recorded demo while we troubleshoot."  

---

## Final POC Checklist

**2 Days Before Finals:**
✅ POC tested 20+ times  
✅ Backup demo video recorded  
✅ App installed on presentation device  
✅ All test videos on device  
✅ PPT finalized and tested  
✅ Code commented and clean  
✅ GitHub repo ready to share  

**Day of Finals:**
✅ Device fully charged  
✅ Backup power bank  
✅ All files on USB  
✅ Printed backup slides  
✅ Calm and confident  

**You Got This! 🚀**