import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';

class ResultsScreen extends StatelessWidget {
  final Map<String, dynamic> result;

  const ResultsScreen({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    final bool isFake = result['is_fake'];
    final double confidence = result['confidence'];
    final Color statusColor = isFake ? Colors.red : Colors.green;
    final String statusText = isFake ? 'DEEPFAKE DETECTED' : 'AUTHENTIC VIDEO';
    final IconData statusIcon = isFake ? Icons.warning_amber_rounded : Icons.verified_user_rounded;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Analysis Report'),
        leading: IconButton(
          icon: const Icon(Icons.close),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            // Status Card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: statusColor.withOpacity(0.3)),
              ),
              child: Column(
                children: [
                  Icon(statusIcon, size: 80, color: statusColor),
                  const SizedBox(height: 16),
                  Text(
                    statusText,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: statusColor,
                      letterSpacing: 1.0,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isFake 
                      ? 'High probability of manipulation detected'
                      : 'No anomalies detected in video stream',
                    style: TextStyle(color: Colors.grey[700]),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Confidence Meter
            CircularPercentIndicator(
              radius: 80.0,
              lineWidth: 12.0,
              animation: true,
              percent: confidence,
              center: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "${(confidence * 100).toStringAsFixed(1)}%",
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 32.0),
                  ),
                  const Text("Confidence", style: TextStyle(color: Colors.grey)),
                ],
              ),
              circularStrokeCap: CircularStrokeCap.round,
              progressColor: statusColor,
              backgroundColor: Colors.grey[200]!,
            ),
            const SizedBox(height: 32),

            // Cognitive Assistance / Details
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'DETAILED ANALYSIS',
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            const SizedBox(height: 16),
            _buildDetailRow(
              context, 
              icon: Icons.face, 
              title: 'Visual Artifacts', 
              score: result['video_score'] ?? 0.0,
              isHighRisk: (result['video_score'] ?? 0.0) > 0.5,
            ),
            _buildDetailRow(
              context, 
              icon: Icons.graphic_eq, 
              title: 'Audio Anomalies', 
              score: result['audio_score'] ?? 0.0,
              isHighRisk: (result['audio_score'] ?? 0.0) > 0.5,
            ),
            _buildDetailRow(
              context, 
              icon: Icons.data_object, 
              title: 'Metadata Integrity', 
              score: 0.1, // Mocked low risk for metadata in this PoC
              isHighRisk: false,
            ),

            const SizedBox(height: 40),
            
            // Action Buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {},
                    child: const Text('SAVE REPORT'),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('NEW SCAN'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(BuildContext context, {required IconData icon, required String title, required double score, required bool isHighRisk}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.grey[50],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: Colors.blue[800]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: score,
                  backgroundColor: Colors.grey[200],
                  valueColor: AlwaysStoppedAnimation<Color>(
                    isHighRisk ? Colors.red : Colors.green,
                  ),
                  minHeight: 4,
                  borderRadius: BorderRadius.circular(2),
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Text(
            isHighRisk ? 'RISK' : 'SAFE',
            style: TextStyle(
              color: isHighRisk ? Colors.red : Colors.green,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
