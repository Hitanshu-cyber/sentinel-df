import 'dart:typed_data';
import 'dart:io';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'package:image/image.dart' as img;

class DetectionService {
  Interpreter? _interpreter;
  bool _isModelLoaded = false;

  /// Initialize the TFLite model
  Future<void> initializeModel() async {
    try {
      // Load the model from assets
      _interpreter = await Interpreter.fromAsset('assets/sentinel_core.tflite');
      _isModelLoaded = true;
      print('✓ TFLite Model Loaded Successfully');
    } catch (e) {
      print('✗ Failed to load model: $e');
      _isModelLoaded = false;
      rethrow;
    }
  }

  /// Analyze an image file and return deepfake probability
  Future<Map<String, dynamic>> analyzeImage(String imagePath) async {
    if (!_isModelLoaded) {
      throw Exception('Model not loaded. Call initializeModel() first.');
    }

    try {
      // Load and preprocess image
      final imageFile = File(imagePath);
      final imageBytes = await imageFile.readAsBytes();
      final image = img.decodeImage(imageBytes);

      if (image == null) {
        throw Exception('Failed to decode image');
      }

      // Resize to 224x224 (MobileNetV2 input size)
      final resizedImage = img.copyResize(image, width: 224, height: 224);

      // Convert to Float32 tensor [1, 224, 224, 3]
      final input = _imageToByteListFloat32(resizedImage);

      // Prepare output tensor [1, 1] - single probability value
      final output = List.filled(1, 0.0).reshape([1, 1]);

      // Run inference
      _interpreter!.run(input, output);

      final fakeConfidence = output[0][0] as double;
      final isAuthentic = fakeConfidence < 0.5;

      return {
        'result': isAuthentic ? 'AUTHENTIC' : 'DEEPFAKE',
        'confidence': isAuthentic ? (1 - fakeConfidence) : fakeConfidence,
        'timestamp': DateTime.now().toIso8601String(),
        'model': 'sentinel_core.tflite',
      };
    } catch (e) {
      print('✗ Analysis error: $e');
      return {
        'result': 'ERROR',
        'error': e.toString(),
        'timestamp': DateTime.now().toIso8601String(),
      };
    }
  }

  /// Analyze video by extracting keyframes
  Future<Map<String, dynamic>> analyzeVideo(String videoPath) async {
    // For video analysis, we'd need to:
    // 1. Extract frames using video_player or ffmpeg
    // 2. Analyze each frame
    // 3. Aggregate results
    // For now, return a simplified response
    return {
      'result': 'VIDEO_ANALYSIS_NOT_IMPLEMENTED',
      'message': 'Use Python backend for video analysis',
      'recommendation': 'Run ml_core/verify_inference.py for video files'
    };
  }

  /// Convert image to Float32 tensor
  Float32List _imageToByteListFloat32(img.Image image) {
    final convertedBytes = Float32List(1 * 224 * 224 * 3);
    final buffer = Float32List.view(convertedBytes.buffer);
    int pixelIndex = 0;

    for (int y = 0; y < 224; y++) {
      for (int x = 0; x < 224; x++) {
        final pixel = image.getPixel(x, y);
        
        // Normalize to [0, 1] range
        buffer[pixelIndex++] = pixel.r / 255.0;
        buffer[pixelIndex++] = pixel.g / 255.0;
        buffer[pixelIndex++] = pixel.b / 255.0;
      }
    }

    return convertedBytes.reshape([1, 224, 224, 3]);
  }

  /// Dispose resources
  void dispose() {
    _interpreter?.close();
    _isModelLoaded = false;
  }
}
