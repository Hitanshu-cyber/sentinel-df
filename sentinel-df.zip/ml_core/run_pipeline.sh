#!/bin/bash

echo "============================================="
echo "SENTINEL-DF: AUTOMATED PIPELINE STARTED"
echo "============================================="

# 1. Activate Environment
source venv/bin/activate

# 2. Process Videos (Extract Faces)
echo "[1/3] Starting Video Pre-processing (This may take hours)..."
cd tools
python process_videos.py
EXIT_CODE=$?
cd ..

if [ $EXIT_CODE -ne 0 ]; then
    echo "❌ Error: Video processing failed."
    exit 1
fi

# 3. Train Model
echo "[2/3] Starting Model Training..."
python train_detect.py
if [ $? -ne 0 ]; then
    echo "❌ Error: Training failed."
    exit 1
fi

echo "============================================="
echo "✅ PIPELINE COMPLETE. Model Ready in dist/"
echo "============================================="
