import cv2
import numpy as np
import time
import os

# Mock TFLite Interpreter if tflite_runtime is not installed
try:
    import tensorflow.lite as tflite
except ImportError:
    try:
        import tflite_runtime.interpreter as tflite
    except ImportError:
        print("Warning: TensorFlow Lite logic will be mocked since tflite is not installed.")
        tflite = None

class DeepfakeDetector:
    def __init__(self, model_path):
        self.model_path = model_path
        self.interpreter = None
        
        if not tflite:
            raise RuntimeError("CRITICAL: TensorFlow Lite Runtime is NOT installed. Cannot run inference.")
            
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"CRITICAL: Model file non-existent at {model_path}")
            
        print(f"Loading Production Model: {model_path}")
        self.interpreter = tflite.Interpreter(model_path=model_path)
        self.interpreter.allocate_tensors()
        self.input_details = self.interpreter.get_input_details()
        self.output_details = self.interpreter.get_output_details()
        print("Model Verified & Loaded.")

    def preprocess_face(self, face):
        """Resize and normalize face for different models (EfficientNet 224x224)"""
        face = cv2.resize(face, (224, 224)) 
        face = face.astype(np.float32) / 255.0
        face = np.expand_dims(face, axis=0)
        return face

    def predict(self, face):
        """Run inference on a single face"""
        input_data = self.preprocess_face(face)
        self.interpreter.set_tensor(self.input_details[0]['index'], input_data)
        self.interpreter.invoke()
        output_data = self.interpreter.get_tensor(self.output_details[0]['index'])
        return output_data[0][0] # Assuming single output probability

    def detect_faces_fast(self, frame):
        """
        Use OpenCV HAAR cascades for fast local detection.
        In production app, use MediaPipe.
        """
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        haar_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        face_cascade = cv2.CascadeClassifier(haar_path)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        extracted_faces = []
        for (x, y, w, h) in faces:
            # Add some margin
            margin = int(w * 0.2)
            x_start = max(x - margin, 0)
            y_start = max(y - margin, 0)
            x_end = min(x + w + margin, frame.shape[1])
            y_end = min(y + h + margin, frame.shape[0])
            
            face_img = frame[y_start:y_end, x_start:x_end]
            extracted_faces.append(face_img)
            
        return extracted_faces

    def analyze_video(self, video_path, speed_mode=True):
        if not os.path.exists(video_path):
            raise FileNotFoundError(f"Video file {video_path} not found.")

        print(f"analyzing {video_path}...")
        cap = cv2.VideoCapture(video_path)
        
        frames_analyzed = 0
        predictions = []
        
        start_time = time.time()
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # SPEED OPTIMIZATION: Process Keyframes only
            if speed_mode and frames_analyzed % 10 != 0:
                frames_analyzed += 1
                continue
                
            faces = self.detect_faces_fast(frame)
            
            for face in faces:
                conf = self.predict(face)
                predictions.append(conf)
            
            frames_analyzed += 1
            
        cap.release()
        duration = end_time - start_time if 'end_time' in locals() else time.time() - start_time
        
        if not predictions:
            return {"status": "NO_FACES_DETECTED", "confidence": 0.0}
            
        avg_conf = np.mean(predictions)
        is_fake = avg_conf > 0.5
        
        return {
            "result": "DEEPFAKE" if is_fake else "AUTHENTIC",
            "confidence": float(avg_conf),
            "engine": "TFLite Edge Runtime"
        }

    def analyze_image(self, image_path):
        if not os.path.exists(image_path):
            raise FileNotFoundError(f"Image {image_path} not found.")
            
        print(f"Analyzing Image: {image_path}")
        frame = cv2.imread(image_path)
        
        faces = self.detect_faces_fast(frame)
        if not faces:
            return {"status": "NO_FACES_DETECTED"}
            
        # Analyze first face
        conf = self.predict(faces[0])
        is_fake = conf > 0.5
        
        return {
            "result": "DEEPFAKE" if is_fake else "AUTHENTIC",
            "confidence": float(conf),
            "type": "IMAGE_SCAN"
        }

if __name__ == "__main__":
    # STRICT PRODUCTION TEST
    # Will fail if model or video is missing.
    model_file = "dist/sentinel_core.tflite"
    test_video = "test_data/input_video.mp4"
    
    print("--- SENTINEL-DF VERIFICATION ---")
    try:
        detector = DeepfakeDetector(model_file)
        result = detector.analyze_video(test_video)
        print("FINAL RESULT:", result)
    except Exception as e:
        print(f"❌ TEST FAILED: {e}")
        print("To run this, you MUST have trained the model and provided a video file.")

