import tensorflow as tf
import os

def convert_model(h5_path, tflite_path):
    print(f"Loading model from {h5_path}...")
    try:
        model = tf.keras.models.load_model(h5_path)
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    print("Converting to TFLite...")
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    
    # OPTIMIZATION: Quantization for speed and size reduction
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    # Reduce to float16 to trade minor precision for 2x size reduction (GPU friendly)
    converter.target_spec.supported_types = [tf.float16]
    
    tflite_model = converter.convert()

    print(f"Saving to {tflite_path}...")
    with open(tflite_path, 'wb') as f:
        f.write(tflite_model)
    
    print("Conversion complete!")

if __name__ == "__main__":
    # Create models directory if not exists
    os.makedirs("models", exist_ok=True)
    
    # Instruction for user
    print("Please place your trained model.h5 in this directory.")
    print("Usage: python model_converter.py")
    
    # Example call (commented out)
    # convert_model("my_efficientnet.h5", "models/sentinel_df.tflite")
