import unittest
import numpy as np
import os
import cv2
from detection_demo import DeepfakeDetector

class TestDeepfakeDetector(unittest.TestCase):
    def setUp(self):
        # Use a dummy path; the class handles missing models with mocks
        self.detector = DeepfakeDetector("models/dummy.tflite")

    def test_initialization_mock(self):
        """Test that detector initializes even without a real model (Mock mode)"""
        self.assertIsNone(self.detector.interpreter)
        print("\n[Test] Initialization (Mock) passed.")

    def test_face_preprocessing(self):
        """Test that face preprocessing returns correct shape and normalization"""
        # Create a dummy face image (100x100 RGB)
        fake_face = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        processed = self.detector.preprocess_face(fake_face)
        
        # Expected: (1, 224, 224, 3) and values in [0, 1]
        self.assertEqual(processed.shape, (1, 224, 224, 3))
        self.assertTrue(processed.max() <= 1.0)
        self.assertTrue(processed.min() >= 0.0)
        print("[Test] Preprocessing passed.")

    def test_predict_mock(self):
        """Test that predict returns a probability"""
        fake_face = np.random.randint(0, 255, (100, 100, 3), dtype=np.uint8)
        confidence = self.detector.predict(fake_face)
        self.assertIsInstance(confidence, float)
        self.assertTrue(0.0 <= confidence <= 1.0)
        print(f"[Test] Mock Prediction passed. Confidence: {confidence}")

    def test_speed_optimization_logic(self):
        """
        Verify that analyze_video would skip frames. 
        Since we can't easily rely on a real video file existing in this env,
        we mimic the logic here or skip if video missing.
        """
        # We will manually test the frame skipping math
        frames_analyzed = 0
        total_frames = 100
        processed_count = 0
        
        for i in range(total_frames):
            if frames_analyzed % 10 != 0:
                frames_analyzed += 1
                continue
            # Process
            processed_count += 1
            frames_analyzed += 1
            
        # If we have 100 frames, and process every 10th (0, 10, 20...), we expect 10 processed
        self.assertEqual(processed_count, 10)
        print("[Test] Speed Visualization (Frame Skipping) logic verified.")

if __name__ == '__main__':
    unittest.main()
