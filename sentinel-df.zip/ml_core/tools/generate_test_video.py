import cv2
import numpy as np
import os

# CONFIG
OUTPUT_FILE = "../test_data/input_video.mp4"
FRAMES = 120 # 4 seconds @ 30fps
IMG_SIZE = (640, 480) # Standard video res

def generate_video():
    if not os.path.exists("../test_data"):
        os.makedirs("../test_data")
        
    print(f"Generating Test Video: {OUTPUT_FILE}...")
    
    # Define codec and create VideoWriter object
    fourcc = cv2.VideoWriter_fourcc(*'mp4v') 
    out = cv2.VideoWriter(OUTPUT_FILE, fourcc, 30.0, IMG_SIZE)
    
    # 0-60 frames: "Real" pattern (Green Circle moving)
    for i in range(60):
        frame = np.zeros((IMG_SIZE[1], IMG_SIZE[0], 3), dtype=np.uint8)
        
        # Move circle across screen
        center_x = 100 + i * 5
        center_y = 240
        
        cv2.circle(frame, (center_x, center_y), 50, (0, 255, 0), -1)
        
        # Add text
        cv2.putText(frame, "TEST PATTERN: REAL (CIRCLE)", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        out.write(frame)
        
    # 60-120 frames: "Fake" pattern (Red Square moving)
    for i in range(60):
        frame = np.zeros((IMG_SIZE[1], IMG_SIZE[0], 3), dtype=np.uint8)
        
        center_x = 400 - i * 5
        center_y = 240
        
        font_pt = (center_x - 40, center_y - 40)
        end_pt = (center_x + 40, center_y + 40)
        
        cv2.rectangle(frame, font_pt, end_pt, (0, 0, 255), -1)
        
        cv2.putText(frame, "TEST PATTERN: FAKE (SQUARE)", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
        
        out.write(frame)
        
    out.release()
    print("Video Generation Complete.")

if __name__ == "__main__":
    generate_video()
