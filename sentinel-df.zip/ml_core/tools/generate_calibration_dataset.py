import cv2
import numpy as np
import os
import shutil

# CONFIG
DATASET_ROOT = "../dataset"
CLASSES = ["real", "fake"]
NUM_IMAGES_PER_CLASS = 50
IMG_SIZE = (224, 224)

def check_dir(path):
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)

def generate_data():
    print(f"Generating Calibration Dataset in {DATASET_ROOT}...")
    
    for class_name in CLASSES:
        dir_path = os.path.join(DATASET_ROOT, class_name)
        check_dir(dir_path)
        
        print(f"Creating {NUM_IMAGES_PER_CLASS} images for class '{class_name}'...")
        
        for i in range(NUM_IMAGES_PER_CLASS):
            # Create a black image
            img = np.zeros((IMG_SIZE[0], IMG_SIZE[1], 3), dtype=np.uint8)
            
            # Add some random background noise so it's not trivial
            noise = np.random.randint(0, 50, (IMG_SIZE[0], IMG_SIZE[1], 3), dtype=np.uint8)
            img = cv2.add(img, noise)
            
            # COLOR logic: Real = Greenish, Fake = Reddish (Visual aid)
            color = (0, 255, 0) if class_name == "real" else (0, 0, 255)
            
            # SHAPE logic: 
            # Real = Circle
            # Fake = Rectangle/Square
            
            center_x = np.random.randint(50, 174)
            center_y = np.random.randint(50, 174)
            
            if class_name == "real":
                radius = np.random.randint(20, 50)
                cv2.circle(img, (center_x, center_y), radius, color, -1)
            else:
                w = np.random.randint(40, 80)
                h = np.random.randint(40, 80)
                font_pt = (center_x - w//2, center_y - h//2)
                end_pt = (center_x + w//2, center_y + h//2)
                cv2.rectangle(img, font_pt, end_pt, color, -1)
                
            # Save as valid JPG
            file_name = f"{class_name}_{i:03d}.jpg"
            file_path = os.path.join(dir_path, file_name)
            cv2.imwrite(file_path, img)
            
    print("Calibration Dataset Generation Complete.")
    print(f"Structure: {DATASET_ROOT}/[real, fake]")

if __name__ == "__main__":
    generate_data()
