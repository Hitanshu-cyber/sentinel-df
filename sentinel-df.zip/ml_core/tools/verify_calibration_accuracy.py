import cv2
import numpy as np
import tensorflow.lite as tflite

# CONFIG
MODEL_PATH = "../dist/sentinel_core.tflite"
VIDEO_PATH = "../test_data/input_video.mp4"

def verify():
    print("Loading Model...")
    interpreter = tflite.Interpreter(model_path=MODEL_PATH)
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()
    output_details = interpreter.get_output_details()
    
    cap = cv2.VideoCapture(VIDEO_PATH)
    frame_count = 0
    correct_predictions = 0
    
    print(f"Analyzing {VIDEO_PATH}...")
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
            
        # Ground Truth: 
        # Frames 0-60: Real (Circle) -> Expect Output < 0.5 (if 0=Real, 1=Fake) 
        # Wait, usually 0=Real, 1=Fake or vice versa depending on alphanumeric sort of class names.
        # Classes: ['fake', 'real']. 
        # Keras usually maps 'fake' -> 0, 'real' -> 1.
        # So Real (Circle) should be ~1.0. Fake (Square) should be ~0.0.
        
        # Preprocess
        img = cv2.resize(frame, (224, 224))
        img = img.astype(np.float32) / 255.0
        img = np.expand_dims(img, axis=0)
        
        # Infer
        interpreter.set_tensor(input_details[0]['index'], img)
        interpreter.invoke()
        output = interpreter.get_tensor(output_details[0]['index'])[0][0]
        
        # Check
        is_real_frame = frame_count < 60
        prediction_is_real = output > 0.5 # Assuming 1=Real
        
        status = "✅" if is_real_frame == prediction_is_real else "❌"
        # print(f"Frame {frame_count}: Score {output:.4f} [{status}]")
        
        if is_real_frame == prediction_is_real:
            correct_predictions += 1
            
        frame_count += 1
        
    accuracy = correct_predictions / frame_count
    print(f"Processed {frame_count} frames.")
    print(f"Calibration Model Accuracy: {accuracy*100:.2f}%")
    
    if accuracy > 0.8:
        print("RESULT: PASS (Model successfully learned patterns)")
    else:
        print("RESULT: FAIL (Model is random)")

if __name__ == "__main__":
    verify()
