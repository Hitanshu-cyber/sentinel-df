#!/usr/bin/env python3
"""
Convert Keras model to TensorFlow.js via SavedModel format.
This avoids Keras version compatibility issues.
"""
import tensorflow as tf
import os

# Load the Keras model
print("Loading Keras model...")
model = tf.keras.models.load_model('dist/sentinel_core.h5', compile=False)

# Save as SavedModel format
saved_model_path = 'dist/saved_model'
print(f"Saving as TensorFlow SavedModel to {saved_model_path}...")
tf.saved_model.save(model, saved_model_path)

print("Conversion to SavedModel complete!")
print(f"Now run: tensorflowjs_converter --input_format=tf_saved_model {saved_model_path} ../sentient_web/models")
