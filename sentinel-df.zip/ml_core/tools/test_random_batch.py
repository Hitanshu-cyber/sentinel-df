import os
import random
import sys
import numpy as np

# Adjust path to import from parent directory
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    from verify_inference import DeepfakeDetector
except ImportError:
    # Quick fix for import if run from tools/
    sys.path.append("../")
    from verify_inference import DeepfakeDetector

# CONFIG
DATASET_DIR = "../dataset"
MODEL_PATH = "../dist/sentinel_core.tflite"
NUM_TESTS = 20 # Total videos (10 Real, 10 Fake)

def run_blind_test():
    print("--- SENTINEL-DF: BLIND RANDOM BATCH TEST ---")
    
    # 1. Verify Model
    if not os.path.exists(MODEL_PATH):
        print(f"❌ Error: Model not found at {MODEL_PATH}")
        return

    # 2. Gather Candidates
    real_dir = os.path.join(DATASET_DIR, "real")
    fake_dir = os.path.join(DATASET_DIR, "fake")
    
    if not os.path.exists(real_dir) or not os.path.exists(fake_dir):
        print("❌ Error: Dataset folders not found.")
        return
        
    all_real = [os.path.join(real_dir, f) for f in os.listdir(real_dir) if f.endswith('.mp4')]
    all_fake = [os.path.join(fake_dir, f) for f in os.listdir(fake_dir) if f.endswith('.mp4')]
    
    print(f"Pool: {len(all_real)} Real, {len(all_fake)} Fake videos.")
    
    if len(all_real) < 10 or len(all_fake) < 10:
        print("⚠️  Warning: Not enough videos for balanced 10/10 split. Using available.")
    
    # 3. Select & Shuffle
    # Safe sample
    n_real = min(10, len(all_real))
    n_fake = min(10, len(all_fake))
    
    batch = []
    # Add tuples: (path, actual_label)
    for p in random.sample(all_real, n_real):
        batch.append((p, "AUTHENTIC"))
    for p in random.sample(all_fake, n_fake):
        batch.append((p, "DEEPFAKE"))
        
    random.shuffle(batch)
    
    print(f"Selected {len(batch)} randomized candidates for testing.")
    print("-" * 60)
    print(f"{'VIDEO ID':<40} | {'ACTUAL':<10} | {'PREDICTED':<10} | {'CONFIDENCE':<8} | {'STATUS'}")
    print("-" * 60)
    
    # 4. Run Inference
    detector = DeepfakeDetector(MODEL_PATH)
    
    correct = 0
    
    for video_path, actual in batch:
        video_name = os.path.basename(video_path)[0:35] + "..." if len(os.path.basename(video_path)) > 38 else os.path.basename(video_path)
        
        # Suppress internal prints of verify_inference
        # (Optional: redirect stdout if needed, but keeping it simple)
        
        try:
            # Run analysis
            result = detector.analyze_video(video_path, speed_mode=True)
            prediction = result['result']
            confidence = result['confidence']
            
            # Check correctness
            is_match = (prediction == actual)
            status = "✅ PASS" if is_match else "❌ FAIL"
            if is_match: correct += 1
            
            print(f"{video_name:<40} | {actual:<10} | {prediction:<10} | {confidence:.1%}    | {status}")
            
        except Exception as e:
            print(f"{video_name:<40} | {actual:<10} | ERROR      | 0.0%     | ⚠️  {str(e)}")

    # 5. Summary
    accuracy = (correct / len(batch)) * 100
    print("-" * 60)
    print(f"TEST COMPLETE. Accuracy: {correct}/{len(batch)} ({accuracy:.1f}%)")
    
    if accuracy < 60:
        print("\n⚠️  Alert: Low Accuracy detected. Did you save the trained model?")
        print("   If you stopped training early, the 'dist/sentinel_core.tflite' might still be the old calibration model.")

if __name__ == "__main__":
    run_blind_test()
