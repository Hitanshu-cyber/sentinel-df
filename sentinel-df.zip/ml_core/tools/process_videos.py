import cv2
import os
import sys
import glob
from pathlib import Path

# CONFIG
SOURCE_DIR = "../dataset"
OUTPUT_DIR = "../dataset_faces"
FRAME_SKIP = 10  # Process every 10th frame to save space/time
IMG_SIZE = (224, 224)

def detect_and_crop_face(frame, face_cascade):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)
    
    if len(faces) == 0:
        return None
        
    # Get the largest face
    (x, y, w, h) = max(faces, key=lambda f: f[2] * f[3])
    
    # Add margin
    margin = int(w * 0.2)
    x = max(0, x - margin)
    y = max(0, y - margin)
    
    # Ensure crop is within frame
    h_img, w_img = frame.shape[:2]
    w = min(w_img - x, w + 2*margin)
    h = min(h_img - y, h + 2*margin)
    
    face_img = frame[y:y+h, x:x+w]
    return cv2.resize(face_img, IMG_SIZE)

def process_dataset():
    print(f"--- SENTINEL-DF: VIDEO PREPROCESSOR ---")
    print(f"Source: {os.path.abspath(SOURCE_DIR)}")
    print(f"Target: {os.path.abspath(OUTPUT_DIR)}")
    
    if not os.path.exists(SOURCE_DIR):
        print(f"Error: Source directory '{SOURCE_DIR}' not found.")
        return

    # Load HAAR Cascade
    haar_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
    face_cascade = cv2.CascadeClassifier(haar_path)
    
    # Find all classes (subdirectories in dataset/)
    classes = [d for d in os.listdir(SOURCE_DIR) if os.path.isdir(os.path.join(SOURCE_DIR, d))]
    
    if not classes:
        print("No class folders found in dataset/. Expecting structure: dataset/real/ and dataset/fake/")
        return

    total_faces = 0
    
    for class_name in classes:
        print(f"\nProcessing Class: '{class_name}'")
        class_src = os.path.join(SOURCE_DIR, class_name)
        class_dst = os.path.join(OUTPUT_DIR, class_name)
        
        os.makedirs(class_dst, exist_ok=True)
        
        # Find videos
        videos = glob.glob(os.path.join(class_src, "*.mp4")) + glob.glob(os.path.join(class_src, "*.avi"))
        print(f"Found {len(videos)} videos.")
        
        for video_path in videos:
            base_name = Path(video_path).stem
            marker_path = os.path.join(class_dst, f".{base_name}.done")
            
            # RESUME LOGIC: Skip if satisfied
            if os.path.exists(marker_path):
                print(f"  > Skipping {base_name} (Already Processed)")
                continue

            cap = cv2.VideoCapture(video_path)
            frame_count = 0
            saved_count = 0
            
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break
                
                if frame_count % FRAME_SKIP == 0:
                    face = detect_and_crop_face(frame, face_cascade)
                    if face is not None:
                        # Save
                        out_name = f"{base_name}_{frame_count}.jpg"
                        cv2.imwrite(os.path.join(class_dst, out_name), face)
                        saved_count += 1
                        total_faces += 1
                        
                frame_count += 1
            
            cap.release()
            
            # Create "Done" marker
            Path(marker_path).touch()
            print(f"  > {base_name}: Extracted {saved_count} faces")
            
    print(f"\nProcessing Complete. Total Faces Extracted: {total_faces}")
    print(f"Ready for training in: {OUTPUT_DIR}")

if __name__ == "__main__":
    process_dataset()
