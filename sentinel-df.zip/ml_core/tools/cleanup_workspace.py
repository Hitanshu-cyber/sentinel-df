import os
import shutil
import sys

# CONFIG
DIST_DIR = "../dist"
RAW_DATA_DIR = "../dataset"
PROCESSED_DATA_DIR = "../dataset_faces"

def get_size(start_path):
    total_size = 0
    for dirpath, dirnames, filenames in os.walk(start_path):
        for f in filenames:
            fp = os.path.join(dirpath, f)
            # skip if it is symbolic link
            if not os.path.islink(fp):
                total_size += os.path.getsize(fp)
    return total_size

def format_size(size_bytes):
    if size_bytes == 0: return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB")
    i = int(0) # 0
    import math
    if size_bytes > 0:
        i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return "%s %s" % (s, size_name[i])

def cleanup():
    print("--- SENTINEL-DF: STORAGE OPTIMIZER ---")
    
    # 1. Verify Intelligence Exists
    model_path = os.path.join(DIST_DIR, "sentinel_core.tflite")
    if not os.path.exists(model_path):
        print("❌ CRITICAL: Trained Model not found in 'dist/'.")
        print("   Cannot clean up data because the Brain is not ready.")
        print("   Please run current pipeline to completion first.")
        sys.exit(1)
        
    print(f"✅ INTELLIGENCE VERIFIED: {model_path} exists.")
    
    # 2. Calculate Reclaimable Space
    size_raw = 0
    size_proc = 0
    
    if os.path.exists(RAW_DATA_DIR):
        size_raw = get_size(RAW_DATA_DIR)
    
    if os.path.exists(PROCESSED_DATA_DIR):
        size_proc = get_size(PROCESSED_DATA_DIR)
        
    total_reclaim = size_raw + size_proc
    
    print(f"   Raw Dataset Content:      {format_size(size_raw)}")
    print(f"   Processed Dataset Content: {format_size(size_proc)}")
    print(f"   TOTAL RECLAIMABLE SPACE:   {format_size(total_reclaim)}")
    
    if total_reclaim == 0:
        print("   Nothing to clean.")
        return

    # 3. Confirm
    val = input("\n⚠️  WARNING: This will PERMANENTLY DELETE all training images/videos.\n   The Model ('Brain') will be kept.\n   Type 'DELETE' to confirm: ")
    
    if val == "DELETE":
        print("\n   Deleting raw data...")
        if os.path.exists(RAW_DATA_DIR):
            shutil.rmtree(RAW_DATA_DIR)
            
        print("   Deleting processed faces...")
        if os.path.exists(PROCESSED_DATA_DIR):
            shutil.rmtree(PROCESSED_DATA_DIR)
            
        print(f"\n✅ CLEANUP COMPLETE. You have saved {format_size(total_reclaim)}.")
    else:
        print("\n   Operation Cancelled.")

if __name__ == "__main__":
    cleanup()
